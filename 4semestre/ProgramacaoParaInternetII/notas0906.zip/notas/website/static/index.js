function deleteNota(notaId) {
    fetch("/delete-Nota", {
        method: "POST",
        body: JSON.stringify({notaId: notaId}),
    }).then(() => {
        window.location.href = "/"
    });
}