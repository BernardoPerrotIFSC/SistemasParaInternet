import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Hello from "./pages/Hello";
import Todo from "./pages/Todo";
import Produto from "./pages/Produto";
import ListaAlbums from "./pages/ListaAlbums";

import Header from "./components/Header";
import CriarAlbums from "./pages/CriarAlbums";

function RoutesApp() {

    return (
        <BrowserRouter>
            <Header />
            <Routes>
                <Route path="/" element={<Home />}/>
                <Route path="/hello" element={<Hello />}/>
                <Route path="/todo" element={<Todo />}/>
                <Route path="/lista" element={<ListaAlbums />}/>
                <Route path="/criar" element={<CriarAlbums />}/>
                <Route path="/produtos/:id" element={<Produto />} />
            </Routes>
        </BrowserRouter>
    )
}

export default RoutesApp;