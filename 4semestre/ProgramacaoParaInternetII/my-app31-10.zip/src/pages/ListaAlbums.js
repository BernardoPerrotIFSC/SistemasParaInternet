import  { useState, useEffect } from 'react';
import api from '../api';

import '../App.css';

function ListaAlbums() {

    const [albums, setAlbums] = useState([])
    useEffect(() => {
        api.get('/albums')
            .then((response) => {
                setAlbums(response.data)
            })
    },[])

    return (
        <ul>
            {albums.map(album => (
                <li key={album.id}>{album.title}</li>
            ))}
        </ul>
    );
}
export default ListaAlbums;