import  { useState } from 'react';
import api from '../api';

import '../App.css';

function CriarAlbums() {
  
    const [id, setId] = useState();
    const [title, setTitle] = useState();
    const [artist, setArtist] = useState();
    const [category, setCategory] = useState();
    const [year, setYear] = useState();
    const [rating, setRating] = useState();

    function handleSubmit() {
        const data = {
            id, title, artist, category, year, rating
        }

        api.post('/albums/create', data).then((response) => {
            alert('Album cadastrado!')
        })
    }

    return (
        <div>
            <h2>Cadastro de Album</h2>
            <form onSubmit={handleSubmit}
                className='Form'
            >
                <input type="number" name="id" placeholder='id' 
                    onChange={(e) => setId(e.target.value)}/>
                <input type="text" name="title" placeholder='title' 
                    onChange={(e) => setTitle(e.target.value)}/>
                <input type="text" name="artist" placeholder='artist'
                    onChange={(e) => setArtist(e.target.value)} />
                <input type="text" name="category" placeholder='category'
                    onChange={(e) => setCategory(e.target.value)}/>
                <input type="number" name="year" placeholder='year' 
                    onChange={(e) => setYear(e.target.value)}/>
                <input type="number" name="rating" placeholder='rating'
                    onChange={(e) => setRating(e.target.value)}/>
                <button type="submit">Salvar</button>
            </form>
        </div>
    );
}
export default CriarAlbums;