import  { useState } from 'react';
import '../App.css';

function Todo() {

    const [input, setInput] = useState('');
    const [tarefas, setTarefas] = useState([
        'Lavar a louça',
        'Estudar React'
    ])

    function newTask(e) {
        e.preventDefault();
        setTarefas([...tarefas, input]);
        setInput('');
    }

    return (

        <div className='App'>
            <h1>Cadastro de Tarefas</h1>

            <form onSubmit={newTask}>
                <input
                    placeholder='Digite uma tarefa'
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                /><br/>
                <button type="submit">Cadastrar</button>
            </form>

            <br/><br/>

            <ul>
                {tarefas.map(tarefa => (
                    <li key={tarefa}>{tarefa}</li>
                ))}
            </ul>
        </div>
    );
}

export default Todo;