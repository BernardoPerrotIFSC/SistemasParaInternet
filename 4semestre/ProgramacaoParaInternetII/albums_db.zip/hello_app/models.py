from database import Base
from sqlalchemy import Column, Integer, String

class Album(Base):

    __tablename__ = 'albums'

    id = Column(Integer, primary_key=True, autoincrement=True, index=True)
    title = Column(String, max_length=200, index=True)
    artist = Column(String, max_length=200)
    category = Column(String, max_length=200)
    year = Column(Integer)
    rating = Column(Integer)
