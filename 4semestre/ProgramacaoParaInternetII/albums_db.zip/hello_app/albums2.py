from fastapi import FastAPI, Path, Query, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from starlette import status

import models
from database import engine, SessionLocal
from sqlalchemy.orm import Session

from typing import Optional, Annotated

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

models.Base.metadata.create_all(bind=engine)

# class Album:
#     def __init__(self, id: int, title: str, artist: str, category: str,
#                  year: int, rating: int):
#         self.id = id
#         self.title = title
#         self.artist = artist
#         self.category = category
#         self.year = year
#         self.rating = rating


class AlbumRequest(BaseModel):
    title: str = Field(min_length=1)
    artist: str = Field(min_length=1)
    category: str = Field(min_length=3, max_length=20)
    year: int = Field(gt=1950, lt=2030)
    rating: int = Field(gt=0, lt=6)


# ALBUMS = [
#     Album(1, 'Whos Next', 'The Who', 'rock', 1971, 5),
#     Album(2, 'Led Zeppelin IV', 'Led Zeppelin', 'rock', 1971, 5),
#     Album(3, 'Hunky Dory', 'David Bowie', 'rock', 1971, 5),
#     Album(4, 'Electric Warrior', 'T. Rex', 'rock', 1971, 5),
#     Album(5, 'Sticky Fingers', 'The Rolling Stones', 'rock', 1971, 5),
#     Album(6, 'Master of Reality', 'Black Sabbath', 'metal', 1971, 5),    
# ]

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
        
db_dependency = Annotated[Session, Depends(get_db)]


@app.get("/albums", status_code=status.HTTP_200_OK)
async def get_all_albums(db: db_dependency):
    return db.query(models.Album).all()

@app.get("/albums/{album_id}", status_code=status.HTTP_200_OK)
async def get_album(db: db_dependency, album_id: int = Path(gt=0)):
    album = db.query(models.Album).get(album_id)
    if not album:
        raise HTTPException(status_code=404, detail='Album not found.')
    return album

@app.get("/albums/rating/{rating}", status_code=status.HTTP_200_OK)
async def get_album(db: db_dependency, rating: int = Path(gt=0, lt=6)):
    albums = db.query(models.Album).filter_by(rating = rating).all()
    if not albums:
        raise HTTPException(status_code=404, detail='Album not found.')
    return albums


@app.get("/albums/year/{year}", status_code=status.HTTP_200_OK)
async def get_album(db: db_dependency, year: int = Path(gt=1950, lt=2030)):
    albums = db.query(models.Album).filter_by(year = year).all()
    if not albums:
        raise HTTPException(status_code=404, detail='Album not found.')
    return albums

@app.post("/albums/create", status_code= status.HTTP_201_CREATED)
async def create_album(db: db_dependency, album_request: AlbumRequest):
    new_album = models.Album(**album_request.model_dump())
    db.add(new_album)
    db.commit()

@app.delete("/albums/delete_album/{album_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_album(db: db_dependency, album_id: int = Path(gt=0)):
    album = db.query(models.Album).get(album_id)
    if not album:
        raise HTTPException(status_code=404, detail='Album not found.')  
    db.delete(album)
    db.commit()

