from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World!!!!!"}

@app.get("/valor/{item}")
async def read_item(item):
    try:
        x = int(item)
    except:
        x = 0
    return {"valor": x}