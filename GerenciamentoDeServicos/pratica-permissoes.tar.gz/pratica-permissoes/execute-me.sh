#!/bin/sh
echo -n "Olá, mundo. Agora são: "
date +%H:%M:%S
