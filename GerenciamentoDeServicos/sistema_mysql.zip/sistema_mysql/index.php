<?php
$servername = "localhost";
$username = "sistemateste";
$password = "teste";
$dbname = "sistemateste";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Erro ao conectar: " . $conn->connect_error);
} 

$sql = "SELECT id, nome FROM so";
$result = $conn->query($sql);

echo "<h1>Dados da tabela SO</h1>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Nome: " . $row["nome"]. "<br>";
    }
} else {
    echo "Nenhum resultado.";
}

$conn->close();
?>
