public class Professor extends Pessoa{
    private String especialidade;

    public Professor(String nome, String especialidade) {
        super(nome);
        this.especialidade = especialidade;
    }
}
