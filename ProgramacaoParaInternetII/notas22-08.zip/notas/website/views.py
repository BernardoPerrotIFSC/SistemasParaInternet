from flask import (Blueprint, render_template, request,
    flash, redirect, url_for, jsonify)
from flask_login import login_required, current_user
import json

from website import db
from .models import Nota

views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST':
        nota = request.form.get('nota')

        if len(nota) < 1:
            flash('Texto da nota é muito curto!', category='error')
        else:
            nova_nota = Nota(texto=nota, usuario_id=current_user.id)
            db.session.add(nova_nota)
            db.session.commit()
            flash("Nota incluída!", category="success")
            return redirect(url_for('views.home'))
    
    return render_template("home.html", usuario=current_user)

@views.route('/delete-Nota', methods=['POST'])
def delete_nota():
    data = json.loads(request.data)
    nota_id = data['notaId']
    nota = Nota.query.get(nota_id)
    if nota:
        if nota.usuario_id == current_user.id:
            db.session.delete(nota)
            db.session.commit()
            flash("Nota excluída!", category="success")
    return jsonify({})