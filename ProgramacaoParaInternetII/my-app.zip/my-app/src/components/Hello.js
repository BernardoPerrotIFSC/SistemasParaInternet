import { useState } from 'react';
import '../App.css';

function Hello() {

  const [mensagem, setMensagem]= useState("Hello World!");

  function trocaMensagem() {
    if (mensagem === "Hello World!") {
      setMensagem("Hello Again!'")
    } else {
      setMensagem("Hello World!")
    }
  }

  return (
    <div className="App">
      <p>{mensagem}</p>
      <button onClick={trocaMensagem}>
        Troca mensagem..
      </button>
    </div>
  );
}

export default Hello;

