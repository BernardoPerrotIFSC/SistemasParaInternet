import  { useState } from 'react';
import '../App.css';

function Todo() {

    const [input, setInput] = useState('');
    const [tarefas, setTarefas] = useState([
        'Lavar a louça',
        'Estudar React'
    ])

    return (

        <div className='App'>
            <h1>Cadastro de Tarefas</h1>

            <ul>
                {tarefas.map(tarefa => (
                    <li key={tarefa}>{tarefa}</li>
                ))}
            </ul>
        </div>
    );
}

export default Todo;