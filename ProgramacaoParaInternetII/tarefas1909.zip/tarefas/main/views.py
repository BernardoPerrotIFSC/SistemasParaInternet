from django.shortcuts import render, redirect
from .models import ToDoList, Item

from .forms import CreateNewList

def create(request):
    if request.method == "POST":
        form = CreateNewList(request.POST)

        if form.is_valid():
            name = form.cleaned_data["name"]
            todo = ToDoList(name=name)
            todo.save()
            request.user.todolist.add(todo)
            return redirect("/%i" % todo.id)
    else:
        form = CreateNewList()

    return render(request, "main/create.html", {"form": form})

    form = CreateNewList()
    return render(request, "main/create.html",
        {"form": form})

def index(request, id):
   lista = ToDoList.objects.get(id=id)
   return render(request, "main/list.html",
        {"lista": lista})
   

def home(response):
    return render(response, "main/home.html")
