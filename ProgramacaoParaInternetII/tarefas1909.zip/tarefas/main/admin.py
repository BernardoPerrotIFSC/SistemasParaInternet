from django.contrib import admin
from main.models import ToDoList, Item

admin.site.register(ToDoList)
admin.site.register(Item)
