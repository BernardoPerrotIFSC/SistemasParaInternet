import { Link } from 'react-router-dom';

function Home() {

    return (
        <div>
            <h1>Bem vindo a nossa Home Page</h1>
            <Link to="/hello">Hello</Link>
            <Link to="/todo">Todo</Link>
        </div>
    );
}

export default Home;