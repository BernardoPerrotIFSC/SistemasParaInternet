import { useParams } from 'react-router-dom';

function Produto() {

    const produtos = ['Banana', "Laranja", "Morango"]

    const { id } = useParams();

    return (
        <div>
            <h2>Página do produto</h2>
            {produtos[id] 
                ? <p>O produto escolhido foi {produtos[id]}</p>
                : <p>Produto não encontrado</p>
            }
        </div>
    );
}

export default Produto;