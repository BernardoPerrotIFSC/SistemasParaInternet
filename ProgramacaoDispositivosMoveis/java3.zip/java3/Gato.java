public final class Gato extends Animal {

    public Gato(){
        super("gato", 4);
    }

    public void falar(){
        System.out.println("miau");
    }

    public void nadar(){
        System.out.println("ODEIO ÁGUA");
    }
}
