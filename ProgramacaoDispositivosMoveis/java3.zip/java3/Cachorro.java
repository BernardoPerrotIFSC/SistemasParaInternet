public final class Cachorro extends Animal{
    
    public Cachorro(){
        super("cachorro", 4);
    }

    public void falar(){
        System.out.println("au au au");
    }
}
