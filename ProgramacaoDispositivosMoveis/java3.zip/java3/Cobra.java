public class Cobra extends Animal{
    
    public Cobra(){
        super("Cobra");
    }

    public void falar(){
        System.out.println("tssssssssss");
    }
}
