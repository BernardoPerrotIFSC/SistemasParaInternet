// interface é um CONTRATO
// interfaces só podem ter métodos abstratos
public interface Passaro {
    public int asas = 2;

    public abstract void voar();
    
}
